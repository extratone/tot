# DavodTime
`MMDDYYYY-hhmmss`

I decided to create my own standardized time format because I was getting tired of getting confused by my own timestamps.

Ex:
01152022-135757