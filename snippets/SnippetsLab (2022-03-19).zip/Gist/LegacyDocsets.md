# How to download and view legacy documentation from Apple (no need to sign in to your dev account)

1. Download the [docset index XML](https://developer.apple.com/library/downloads/docset-index.dvtdownloadableindex).
2. Find the docset you want (there are some with URL https://apple.com/none.dmg; ignore them - you will find them again further down the file with a working URL).
3. Download the dmg. It's probably around a gigabyte or so.
4. "Install" the .pkg file somewhere on your disk. If you don't trust the installer, do it manually:
   1. Find the largest file, named Payload, and extract it using The Unarchiver.
   2. This creates a new, even larger file, probably named Payload-1.
   3. Extract Payload-1 using The Unarchiver.
5. After many minutes of extracting, we have our .docset file.
6. Use Kapeli Dash to browse and read the docset.

Why? Because Apple's old docs are often more verbose, and because they didn't mix iOS and macOS docs into one big mess. Or just because you need good information for backward compatibility, or what the official word was back in time.