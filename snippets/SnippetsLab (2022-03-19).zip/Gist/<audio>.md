```
<audio controls>
  <source src="https://github.com/extratone/bilge/raw/main/audio/Mono.mp3">
</audio>
```