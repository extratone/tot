**Create a .txt file in the following format in the same directory as the files to be merged.**

```txt
file '/downloads/152.mp4'
file '/downloads/151.mp4'
```
`ffmpeg -f concat -i [saidfile].txt -c copy output.mp4`

***
# Convert .mov file to .mp4 in a single command.
`ffmpeg -i obit.mov -vcodec h264 -acodec mp2 obit.mp4`