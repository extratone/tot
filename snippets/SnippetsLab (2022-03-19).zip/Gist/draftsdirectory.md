# David Blue’s Drafts Action Directory Contributions
### Actions
- [Fetch contents of # Tot Dot | Drafts Directory](https://actions.getdrafts.com/a/1ub)
- [Send Draft to Telegram Saved Messages | Drafts Directory](https://actions.getdrafts.com/a/1u5)
- [Append to 7th Tot Dot | Drafts Directory](https://actions.getdrafts.com/a/1uL)
- [List Action Shortcuts, Comma-Delimited | Drafts Directory](https://actions.getdrafts.com/a/1s7)
- [Markdown Footnote (Variation) | Drafts Directory](https://actions.getdrafts.com/a/1q9)
- [Markdown Emphasis (*) | Drafts Directory](https://actions.getdrafts.com/a/1pa)
- [Embed <audio> Element | Drafts Directory](https://actions.getdrafts.com/a/1lM)

### Action Groups
- [NeoCities | Drafts Directory](https://actions.getdrafts.com/g/1uF)

### Themes
- [The Psalms | Drafts Directory](https://actions.getdrafts.com/t/1km)
- [Windows Iowa | Drafts Directory](https://actions.getdrafts.com/t/1kY)
