See the [original repo](https://github.com/embedas/go-embed) for the most up-to-date list.

## Supported Providers

- Airtable
- Are.na
- Bandcamp
- Cinnamon
- CloudApp
- Codepen
- Flickr
- Giphy
- GitHub Gists
- Gfycat
- Hype Machine
- Imgur
- Instagram
- Kickstarter
- Last.fm
- Mixcloud
- Rdio
- Spotify
- Tumblr
- Typeform
- Quora
- SoundCloud
- Twitter
- YouTube