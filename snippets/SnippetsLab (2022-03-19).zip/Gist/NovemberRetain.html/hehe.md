# I just discovered what a "Gist" is on GitHub

...and I'm just wondering...  why don't we just fucking *publish* shit this way?
You could very easily run a hefty academic journal with just .md files on GitHub Pages.