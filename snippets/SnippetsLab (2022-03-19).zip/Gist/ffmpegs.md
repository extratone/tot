1. Converting .ts files to .mp4 files with ffmpeg.
`ffmpeg -i xperia.ts -c:v libx264 -c:a aac xperia.mp4`

2. Converting .mov to mp4.
`ffmpeg -i decision.mov -vcodec h264 -acodec mp2 decision.mp4`