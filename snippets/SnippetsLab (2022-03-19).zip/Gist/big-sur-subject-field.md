Want the Subject field (for bold iMessages) in macOS Big Sur's Messages app?

1. Quit Messages
1. Open Terminal
1. Run `defaults write com.apple.MobileSMS MMSShowSubject 1`
1. Start Messages