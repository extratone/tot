## Customized (For my use.)

```
wget -e robots=off -R mpg,mpeg,mp4,mov,wav,tgz,zip,flv --recursive --page-requisites --adjust-extension --span-hosts --convert-links --restrict-file-names=windows --domains bilge.world --no-parent bilge.world
```

```
wget --recursive --page-requisites --adjust-extension --span-hosts --convert-links --restrict-file-names=windows --domains extratone.com --no-parent extratone.com
```

* [**Original source!**](https://gist.github.com/mikecrittenden/fe02c59fed1aeebd0a9697cf7e9f5c0c)