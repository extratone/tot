# Command Browser Bluetooth Keyboard Shortcuts
| Action     | Keys      |
|:----------:|:---------:|
| Search     | ⌘ + L     |
| New Tab    | ⌘ + T     |
| Close Tab  | ⌘ + W     |
| Tabs       | ⌘ + M     |
| Highlights | ⇧ + ⌘ + H |
| Save       | ⌘ + S     |
| Find       | ⌘ + F     |
| Refresh    | ⌘ + R     |
| All Saves  | ⇧ + ⌘ + F |
| Share      | ⇧ + ⌘ + S |
| Back       | ⌘ + [     |
| Forth      | ⌘ + ]     |
| Next Tab   | ⌃+ ⇥      |
| Note       | ⌘ + N     |
| Journals   | ⌘ + J     |