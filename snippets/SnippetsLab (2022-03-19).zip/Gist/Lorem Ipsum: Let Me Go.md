somewhere out there... lives at least one graduate student who's *only* significant challenge in school is entitling his essays. research, writing, peer-review come easy, but the titles...

he is so terrified of anyone figuring this out that he plagiarizes titles and ONLY titles, hyperventilating and sweating his ass off... he wishes so desperately that he could just use a number document ID on the title page... he cannot go on like this.

his doctoral thesis is expected in three days. it is a masterpiece... relevant, original, impeccably documented.

in fact, it is so good that its title is almost certainly going to be attached to his name for the rest of his academic career and on.. if only it had one.

he can't sleep... he's losing his mind. he's going to be ruined! all of the tutoring and the schmoozing and the constant, careful adjustment of his social orientation within the grant-sustained meritocracy for enough favors (its currency) for the asks to craft such a thing.

he has decided he's either going to End It All, leave the country forever, or name it "ˡᵒʳᵉᵐ ᶤᵖˢᵘᵐ: ˡᵉᵗ ᵐᵉ ᵇᵉ ᶠʳᵉᵉ" and attempt to convince the leadership of his department that he was a danger to others as long as he was allowed to move freely through society.

UNTIL HE ENCOUNTERED THIS VERY GIST...

and paid me to come up with the title for his chef d'oeuvre, which took me all of 20 minutes:

*Epilogue and Gender in Revision-Agnostic Documentation: Representing Callous Fetishization*