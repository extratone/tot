This file is here as a way to rename the gist, but I'll use it as a readme

Unfortunately there is currently no way to create a pull request in gists, so 
you'll have to message me if you want changes in here, but please feel free to 
do so - if there is enough engagement I'll upgrade it to a proper repo