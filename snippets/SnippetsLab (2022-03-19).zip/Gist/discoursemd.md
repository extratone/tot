# Discourse Post to Raw Markdown

**Source**: [Export topic as markdown (enabled for all participants) - feature - Discourse Meta](https://meta.discourse.org/t/export-topic-as-markdown-enabled-for-all-participants/152185)

The native URL to the thread:
`https://meta.discourse.org/t/export-topic-as-markdown-enabled-for-all-participants/152185`

By eliminating the topic title from a given post’s URL (`t/export-topic-as-markdown-enabled-for-all-participants`) and prepending `raw/`, we’re left only with the post ID (`152185`).

The [whole URL](https://meta.discourse.org/raw/152185) will take one to the plain text of the post with Markdown formatting.
`https://meta.discourse.org/raw/152185`

As [one of the replies to that thread](https://meta.discourse.org/t/export-topic-as-markdown-enabled-for-all-participants/152185/3) notes, this unfortunately has to be done post-by-post by appending the post’s order number. 

`https://meta.discourse.org/raw/152185/3`
