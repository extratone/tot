```
ffmpeg -i xperia.ts -c:v libx264 -c:a aac xperia.mp4
```