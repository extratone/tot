## An (ongoing) list of handy Unicode-based tools for absolutely destroying text, everywhere.

### Resources

* [Online Unicode Tools](https://onlineunicodetools.com/)

## Web

* [**Zalgo**](http://eeemo.net/)
  (+ [my backup](https://davidblue.xyz/zalgo))
* [**MegaCoolText**](http://megacooltext.com/)
  (+ [my backup](https://davidblue.xyz/cool/))
* [**WeirdTextGenerator**](https://lingojam.com/WeirdTextGenerator)
* [**UniChar Web App**](https://unichar.app/web/)
* [**One-Page Unicode Characters**](https://github.com/taroyabuki/onepage-unicode-chars)
  (+ [my fork](https://github.com/extratone/uni))

## iOS

* [**UniChar**](https://apps.apple.com/us/app/unichar-unicode-keyboard/id880811847)
  (+ [my review](https://bilge.world/unichar-for-ios-app-review))
* [**Zalgo Generator**](https://apps.apple.com/us/app/zalgo-generator/id1178473555)
  (+ [my review](https://bilge.world/zalgo-generator-ios-app-review))