# Potential Twitter Usernames
dusty
bogus
bilge
bunk
scrub
blimp
zro