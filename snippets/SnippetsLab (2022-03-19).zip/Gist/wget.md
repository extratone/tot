    $ wget -e robots=off -r -np 'http://example.com/folder/'

* -e robots=off causes it to ignore robots.txt for that domain
* -r makes it recursive
* -np = no parents, so it doesn't follow links up to the parent folder