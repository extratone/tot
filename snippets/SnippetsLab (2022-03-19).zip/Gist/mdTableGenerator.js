var rows = Number(%filltext:name=bodyrows:default=2:width=5%); //body of table rows
var cols  = Number(%filltext:name=cols:default=4:width=5%); //columns of table
var rows = rows + 2; //add a rows to account for header and seperator
var text  = ''; //variable to store the output

for (rCount = 1; rCount <= rows; rCount++) {
  for (cCount = 1; cCount <= cols; cCount++) {
    if (rCount == 1) { // Header Row Output
      if (cCount == 1) {
        text += '**%|** |';
      }
      else if (cCount == cols) {
        text += ' **Header**';
      }
      else {
        text += ' **Header** |';
      }
    }
    else if (rCount == 2) { // seperator row output
      if (cCount == 1) {
        text += '-- |';
      }
      else if (cCount == cols) {
        text += ' --';
      }
      else {
        text += ' -- |';
      }
    }
    else { //content row outputs
      if (cCount == 1) {
        text += (rCount-2).toString() + 'x' + cCount.toString() + ' |';
      }
      else if (cCount == cols) {
        text += ' ' + (rCount-2).toString() + 'x' + cCount.toString();
      }
      else {
        text += ' ' + (rCount-2).toString() + 'x' + cCount.toString() + ' |';
      }
    }
  }
  text += '\n';
}

TextExpander.appendOutput(text);
