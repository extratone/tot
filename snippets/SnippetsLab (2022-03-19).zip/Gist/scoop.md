 Apple Scoop Discord Conversation Mar 15, 2021
David Blue 15-Mar-21 10:00 PM    wow… I think y’all’s website might be the most beautiful mobile web property I’ve ever seen.

David Blue [wow… I think y’all’s website might be the most beautiful mobile web property I’ve ever seen.]() 

Flynn 15-Mar-21 10:02 PM

Wow what a compliment, thanks so much man! @Luke and I wrote it together. We’re really glad you are liking it

2

David Blue [wow… I think y’all’s website might be the most beautiful mobile web property I’ve ever seen.]() 

Sam 15-Mar-21 10:04 PM    It honestly is NGL

I love the logo to

David Blue 15-Mar-21 10:05 PM    very very impressive. I’m a media nerd so I’ve seen *a lot* of sites on the world wide web. like… a lot. I also have ranted about mobile-optimized web development for years, but this… is something else. did you guys just build your own CMS from scratch? 

1

David Blue [very very impressive. I’m a media nerd so I’ve seen a lot of sites on the world wide web. like… a lot. I also have ranted about mobile-optimized web development for years, but this… is something else. did you guys just build your own CMS from scratch?]() 

Flynn 15-Mar-21 10:09 PM    Well that’s even more of a big compliment then, thank you! It was built mobile first so there was a lot of focus on the mobile design and layout. And yeah, so the whole website is custom built, and a few members are using our custom CMS. Since we had to make one we decided to make it really beautiful and intuitive haha, it’s complex but it’s a good challenge

Flynn [Well that’s even more of a big compliment then, thank you! It was built mobile first so there was a lot of focus on the mobile design and layout. And yeah, so the whole website is custom built, and a few members are using our custom CMS. Since we had to make one we decided to make it really beautiful and intuitive haha, it’s complex but it’s a good challenge]() 

Sam 15-Mar-21 10:09 PM    Niceeeee

Flynn 15-Mar-21 10:10 PM    It’s called ASTA (Apple Scoop Terminal Access) and I’m gonna delete this message soon cause it’s supposed to be secret shhhh @David Blue (edited)

  

1

David Blue 15-Mar-21 10:19 PM    omg you even made the backend pretty lol.

I *love* the name. and that you named it. 

David Blue [omg you even made the backend pretty lol.]() 

Flynn 15-Mar-21 10:22 PM    Ahaha yep

couldn’t resist the temptation. And yeah if you have to make it, may as well make it look and sound really cool right? It has been really fun making it, not gonna lie, and the results are worth it

It even has a little greeting that changes according to the time of day @David Blue

David Blue 15-Mar-21 10:22 PM    I saw that! hehe

the cynical media person in me can’t help but think about how you could license it. from what I’m seeing, I can imagine some Bustle or Vox-type company salivating.

genuine innovation is so precious on the web…

David Blue [the cynical media person in me can’t help but think about how you could license it. from what I’m seeing, I can imagine some Bustle or Vox-type company salivating.]() 

Liam 15-Mar-21 10:25 PM    Yeah, Vox's Chorus system is HUGELY popular for publishing.

David Blue 15-Mar-21 10:26 PM    I remember when they first talked about it publicly.

David Blue [I remember when they first talked about it publicly.]() 

Liam 15-Mar-21 10:26 PM    Same

David Blue 15-Mar-21 10:26 PM    *The Outline* ’s CMS is under all Bustle properties now. 

I was about to remark that theirs was the last site I remember seeing that felt as original as this.

and that was *5 years ago*, now…. christ. 

David Blue [the cynical media person in me can’t help but think about how you could license it. from what I’m seeing, I can imagine some Bustle or Vox-type company salivating.]() 

Flynn 15-Mar-21 10:27 PM    It totally could be if we perfected it a lot, or if it was modified a bit to fit more purposes. The main thing is that it’s just supposed to be incredibly simple with no unnecessary distractions anywhere

David Blue 15-Mar-21 10:28 PM    I believe you but… when’s the last time you saw a new CMS that *wasn’t* described as distraction-minimizing lmao 

2

Liam [Yeah, Vox's Chorus system is HUGELY popular for publishing.]() 

Flynn 15-Mar-21 10:28 PM    I’ve never heard of that before but I’ll look it up, I always just make everything custom because to me it’s easier




Flynn [I’ve never heard of that before but I’ll look it up, I always just make everything custom because to me it’s easier]()

 

  

Liam 15-Mar-21 10:29 PM    Yeah, I prefer custom solutions as well

David Blue [I believe you but… when’s the last time you saw a new CMS that wasn’t described as distraction-minimizing lmao]() 

Flynn 15-Mar-21 10:29 PM    So true! It’s probably because the CMS and the website weren’t designed together at all. Everything just works nicer when it’s designed in unison

Flynn [I’ve never heard of that before but I’ll look it up, I always just make everything custom because to me it’s easier]()

 

  

David Blue 15-Mar-21 10:30 PM    I’ve discouraged quite a few people over the years *not* to build their own CMS but uh… jesus man. not you lol 

Liam 15-Mar-21 10:30 PM    I can't WAIT to use ASTA!

David Blue 15-Mar-21 10:31 PM    I wonder if NiemanLab would do a profile on you guys…

David Blue [I’ve discouraged quite a few people over the years not to build their own CMS but uh… jesus man. not you lol]() 

Flynn 15-Mar-21 10:32 PM    LMAO yeah honestly I probably wouldn’t recommend it to many people either

but I’ve built a bunch of them before so I slowly learnt how to do it somewhat nicely

David Blue [I wonder if NiemanLab would do a profile on you guys…]() 

Flynn 15-Mar-21 10:32 PM    Oooh damn I wish, that would be amazing

David Blue 15-Mar-21 10:32 PM

‍♂️

I don’t know anybody there but I’m assuming there’s quite a bit to the story.

David Blue [I wonder if NiemanLab would do a profile on you guys…]() 

Liam 15-Mar-21 10:33 PM    That'd be amazing dude.

Liam [I can't WAIT to use ASTA!]() 

Flynn 15-Mar-21 10:34 PM    Yeah it’s really gonna speed everything up! From my use so far it’s been a life saver, compared to manually inserting it into the database each time RIP

David Blue 15-Mar-21 10:34 PM    harvard probably thinks itself better than “Apple Bloggers” but idk…

David Blue [harvard probably thinks itself better than “Apple Bloggers” but idk…]() 

Flynn 15-Mar-21 10:34 PM    Hahah yeah true

maybe if we just get so good they can’t ignore us anymore

David Blue 15-Mar-21 10:36 PM    the whole reason I’m here is that I’ve 1) been diving into iOS real deep so far this year to write some big reflection on what’s changed and 2) as a component of this, I’ve noticed many of the “Apple-adjacent” sites seem to have turned into legitimate technology news publications, if you know what I mean.

David Blue [the whole reason I’m here is that I’ve 1) been diving into iOS real deep so far this year to write some big reflection on what’s changed and 2) as a component of this, I’ve noticed many of the “Apple-adjacent” sites seem to have turned into legitimate technology news publications, if you know what I mean.]() 

Flynn 15-Mar-21 10:37 PM    Oh cool! How do you like iOS now? And yeah they really have over the years, it’s been really interesting to watch. I just wish they’d update their design into the 21st century

David Blue 15-Mar-21 10:43 PM    yes… that’s exactly what I was thinking lol. I’ve been using iOS the whole time (and writing intermittently about it and a few apps,) but after buying a 12 Pro Max in early December, I guess the scope of how much it’s changed since I got my first-gen at age 14 really hit me and forced me to reconcile with just how large a presence iOS and iPhone have had in my life. the theme I keep coming back to is just how *excessive* our expectation of handsets have become as well as how much Apple’s attitudes have changed. 

1

like… if I can run a FULL LINUX SHELL on my goddamned iPhone…. “walled garden” doesn’t exactly make sense as applied to Apple anymore lol

idk if I’ve actually gathered any insight… its very possible I have completely lost my mind spending all day every day in an 8 x 15 room messing around with my phone lol

David Blue [yes… that’s exactly what I was thinking lol. I’ve been using iOS the whole time (and writing intermittently about it and a few apps,) but after buying a 12 Pro Max in early December, I guess the scope of how much it’s changed since I got my first-gen at age 14 really hit me and forced me to reconcile with just how large a presence iOS and iPhone have had in my life. the theme I keep coming back to is just how excessive our expectation of handsets have become as well as how much Apple’s attitudes have changed.]() 

Flynn 15-Mar-21 10:48 PM    Damn that’s really interesting. You’re so right though, it really has become a crucial thing in our lives, like for me personally I do my whole career through my Apple devices so it’s hard to even think what life would be like

and yeah my guess is that Apple’s attitudes have changed to keep up with what consumers want

David Blue 15-Mar-21 10:48 PM    I appreciate you indulging me on that, btw. I think my Twitter friends assume I have completely lost it lol

Flynn [Damn that’s really interesting. You’re so right though, it really has become a crucial thing in our lives, like for me personally I do my whole career through my Apple devices so it’s hard to even think what life would be like]()

[and yeah my guess is that Apple’s attitudes have changed to keep up with what consumers want]() 

David Blue 15-Mar-21 10:49 PM    have you read federico vittici’s work on his experiences making the iPad Pro his primary computer?

David Blue [I appreciate you indulging me on that, btw. I think my Twitter friends assume I have completely lost it lol]() 

Liam 15-Mar-21 10:49 PM    Lmao haven't we all, to some extent...

David Blue [idk if I’ve actually gathered any insight… its very possible I have completely lost my mind spending all day every day in an 8 x 15 room messing around with my phone lol]() 

Flynn 15-Mar-21 10:50 PM



I feel that man. Lockdown vibes. But no you’re definitely making sense, how long have you been writing for?

David Blue 15-Mar-21 10:50 PM    I distinctly remember when **nobody knew what my iPhone was**. for like… almost two years after I got it. 

David Blue [have you read federico vittici’s work on his experiences making the iPad Pro his primary computer?]() 

Flynn 15-Mar-21 10:50 PM    No I haven’t! But I’ll go have a look, I tried it myself and it was kinda painful not gonna lie

David Blue [I distinctly remember when nobody knew what my iPhone was. for like… almost two years after I got it.]() 

Flynn 15-Mar-21 10:51 PM    Seriously? That’s insane

did you have the first gen?

No one knew what it was

that’s weird to think about now

Flynn [No I haven’t! But I’ll go have a look, I tried it myself and it was kinda painful not gonna lie]() 

David Blue 15-Mar-21 10:52 PM    painful…. yes… especially in 2015. my mom has an iPad Air 2 and all it’s good for is browsing Pinterest lol. [https://www.macstories.net/stories/ipad-air-2-review-why-the-ipad-became-my-main-computer/]() 

[Federico Viticci]()  
[iPad Air 2 Review: Why the iPad Became My Main Computer]() 
Last week, I came across Kyle Vanhemert’s story for Wired about the iPad and pondered, with a bit of fascination and surprise, his conclusion that “nobody knows what the iPad is good for anymore”. In particular, two arguments from the piece stood out to me. First, Vanhemert argues that iPhone software is unequivocally superior to

  

1

Flynn [Seriously? That’s insane]()

[did you have the first gen?]() 

David Blue 15-Mar-21 10:53 PM    I did indeed! I was 14. walking into 8th grade with a leather iPhone holster on my belt….. lmao

1

as far as writing about tech: I’ve only recently done it intentionally, but I’ve inadvertently found myself writing occasionally about it since 2015 or so.

David Blue [painful…. yes… especially in 2015. my mom has an iPad Air 2 and all it’s good for is browsing Pinterest lol. https://www.macstories.net/stories/ipad-air-2-review-why-the-ipad-became-my-main-computer/]()   

Flynn 15-Mar-21 10:55 PM    Yeah I think the iPad is best really for like browsing the web, watching content, games, art, graphics etc. Like for example our logo is drawn with iPad + Apple Pencil

but for some things it really is a pain, like coding or serious productivity using lots of different apps

David Blue 15-Mar-21 10:56 PM    well if you’re interested in iOS workflow, *MacStories* is the place, man. their membership weekly newsletters are wonderful. 

David Blue [as far as writing about tech: I’ve only recently done it intentionally, but I’ve inadvertently found myself writing occasionally about it since 2015 or so.]() 

Flynn 15-Mar-21 10:57 PM    Cool! I’ve only been writing since like last year so mine is probably no where near as good as yours. Do you enjoy it?

David Blue [well if you’re interested in iOS workflow, MacStories is the place, man. their membership weekly newsletters are wonderful.]() 

Flynn 15-Mar-21 10:57 PM    Ooh sweet I’ll go have a look! I didn’t know they also had a newsletter (edited)

David Blue 15-Mar-21 11:04 PM    that’s a good question… I’ve almost definitely gotten less eloquent after going sober… I entertain ideas of working as a tech journalist, but have serious reservations about the state of tech media, right now. I’m not sure if I actually enjoy the process, but I can tell you that the most joy I’ve experienced at this point in my life comes when someone tells me I’ve helped them discover something that made their user experience better. the smallest stuff… literally individual keyboard shortcuts. an internet friend told me he hadn’t heard of Alt-L to select the text of the URL in a web browser (Cmd-L on iOS/MacOS) and he *writes a weekly newsletter* lol 

1

I’ll allow myself to share a single one of my links here and then I’ve gotta get back to work lol. I wrote about why Tweetbot’s developers have continued to develop on a gosh darned third-party mobile Twitter client in 2021. [https://bilge.world/tweetbot-6-ios-review]() 

[Tweetbot 6 for iOS Review — The Psalms]() 
Tweetbot Resurrection In the bleak face of Twitter’s centralization, Tapbots refuses to give up on its mobile client. Were it just I wh...

  

thank you so much for asking questions and listening on this stuff with me though! I really appreciate it. I’ll make sure to be around.

1

David Blue [that’s a good question… I’ve almost definitely gotten less eloquent after going sober… I entertain ideas of working as a tech journalist, but have serious reservations about the state of tech media, right now. I’m not sure if I actually enjoy the process, but I can tell you that the most joy I’ve experienced at this point in my life comes when someone tells me I’ve helped them discover something that made their user experience better. the smallest stuff… literally individual keyboard shortcuts. an internet friend told me he hadn’t heard of Alt-L to select the text of the URL in a web browser (Cmd-L on iOS/MacOS) and he writes a weekly newsletter lol]() 

Flynn 15-Mar-21 11:08 PM    But hey congrats on going sober though that’s huge! Yeah the process can be time consuming overall but that’s exactly it, when people tell you that something you said really helped them or that what you’re doing is helpful it kinda makes it worth it

1

David Blue [I’ll allow myself to share a single one of my links here and then I’ve gotta get back to work lol. I wrote about why Tweetbot’s developers have continued to develop on a gosh darned third-party mobile Twitter client in 2021. https://bilge.world/tweetbot-6-ios-review]()   

Flynn 15-Mar-21 11:08 PM    Sweet I’ll give it a read! And no worries man, thanks for chatting with us/me too, feel free to come in here any time you like

#correspondence #archive #i