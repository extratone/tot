## Warning: There are *definitely* going to be duplicates.
***

https://www.pscp.tv/jfmanory

Watch on #Periscope: 8 days until #Periscope Dies: how to download your scopes | (Ongoing Gist: http://bit.ly/scopeforever)

https://www.pscp.tv/w/cyoNrjU0ODY4ODB8MW1ueGVhWHlham94WMWQOw8P8j8wTBcLsZgtGKpBUmJgL-Q90WkmV7-IrYPn


LIVE on #Periscope: Periscope Funeral II (7 Days Left)

https://www.pscp.tv/w/cyogETU0ODY4ODB8MWVhS2JucGRkWG5LWIvIi9D73gxHS6R-eu2b3cJUz2e6FNH6sgFRM3XrMBPv


Watch 👩‍❤️‍💋‍👨Kristi Ann Jester💋's broadcast: Walking last scope for periscope last #7days

https://www.pscp.tv/w/cysleDU0ODY4ODB8MVJEeGxQbkF5Z0R4TFQF0X-a6QJpL5h2q9SW_DBiFYFhl4xHS-L1ZpSebWu0


Watch @MTendsToTravel's broadcast: Saying goodbye to the spiral staircase (oh, yeah, and Periscope) 😎

https://www.pscp.tv/w/cy5qBzU0ODY4ODB8MWxQS3FYbllhcE14YiZBbc8_j4n8gISGeEaioJ4ah9HuH94B2lK3pmEtzjmz


https://www.pscp.tv/westiewonder

https://www.pscp.tv/w/cy5qBzU0ODY4ODB8MWxQS3FYbllhcE14YiZBbc8_j4n8gISGeEaioJ4ah9HuH94B2lK3pmEtzjmz

‪#Periscope users looking for a way to keep in touch: I will add literally anybody to this List if we could use it as a temporary solution for a scoper directory- just tell me. ‬

https://twitter.com/i/lists/1374664072654958594

Watch 🇨🇳李铁锤's broadcast: The last day of periscope!

https://www.pscp.tv/w/cy6EYjU0ODY4ODB8MXluSk9CQWtXbXZHUryBLCEuLwI5a9kn5CHUddJ3v1AjySBqRmJb_r-4D709


Watch @Jculturefan1's broadcast: Depressed

https://www.pscp.tv/w/cy6ICTU0ODY4ODB8MXluSk9CQWtvdm5HUu0sa8MIr59tvC5begZjIz8AvGmH0FaGJvXKCK1kORzI


Watch @JeffsJourney_Eh's broadcast: Broadcast #5 - Our last Saturday night here🙁let’s have dinner 🥩🥦and fun #love #chat #BeKind 🙏🤗

https://www.pscp.tv/w/cy6I-TU0ODY4ODB8MUJSS2pCckFvZ1ZLdw7rha8BTDG5bbB_pDEafZleSqYpQPbZQSv2_fGjgZH6


Watch @Dj_Zap's broadcast: The Last Saturday in the Scope 3-27-21 #Thedungeonparty #Thedungeonfam #fortheloveofmusic #musicheals #LetRideYall

https://www.pscp.tv/w/cy6JVzU0ODY4ODB8MVlxSkRlZEROb2F4VoHqZjGLopQ14USTonZeW9JZItNS5fLcukBf3TgcAEzw


Watch t's broadcast: for the last mfn time

https://www.pscp.tv/w/cy6JZzU0ODY4ODB8MVJEeGxQZG9SbXJ4TI1tyBiLHNhzSnQ6XJDP24u8q4DJcyF_Tw0SOILcDlae


Watch @kcjarvis's broadcast: MAJOR ANNOUNCEMENT: LAST PERISCOPE!!!!!!! New Group, New Platform #KJsAmazingSummer2021 #TodayInTravel

https://www.pscp.tv/w/cy6JdDU0ODY4ODB8MXluS09Cb3lxdkF4UsxbjkyYI9BvdKLeZbmqoJR-yXhxm0N5x-7hxOPuAseP


Watch @TimothyDavidTV's broadcast: Follow me on @HappsNews https://happs.tv/invite/@TimothyDavidTV

https://www.pscp.tv/w/cy6KzzU0ODY4ODB8MWt2SnBvV3FrUWtHRVs5SBdnbNi4wpZoH4dFyb55Jp6TQmElvkKHfhUZAOTB


Watch @DOOMSDAY_2021's broadcast: Good bye👋🔥Periscope🔥📹🌎📹🤣

https://www.pscp.tv/w/cy6LljU0ODY4ODB8MWxQSnFYbllnRExHYoJ-MvmCDeTvHOJhyBsp5dnTXxNXG62c4iSitqjkLTyk


https://www.pscp.tv/w/1yoKMAknoEWKQ

Watch @kanji_k's broadcast: 6days to go until Periscope will go away. From my neighborhood 🌸

https://www.pscp.tv/w/cy6L5DU0ODY4ODB8MXlvS01Ba25vRVdLUXYesGUAYsikUVEAE2UogSPk4WzCOLaRls7EVE36edrn


Watch @mikuohashi_ch's broadcast: #Goodbye #Periscope #http://live.sk-knower.com/user/xmikuohashix

https://www.pscp.tv/w/cy6MATU0ODY4ODB8MXlvSk1Ba0RPWk5KUcqDu6uExvShCRFAvbHjn_akSgy94lGqIRxBDPWthzuN


Watch @kcjarvis's broadcast: Good BYE Periscope HELLO Happs  TEST BROADCAST. 🎥 Subscribe at Happs: https://happs.tv/@KenJarvis #live

https://www.pscp.tv/w/cy6MGTU0ODY4ODB8MXlOeGFXa0FNVmdHasgT8zhUWmnADZHAgSNz9vuBrtZxuWivLU58E5JJXSpa


# "[Periscope] has made me a better person and a better scientist."

[Tweet](https://twitter.com/_anthropoid/status/1375899651052736514?s=21)

A bunch of Periscope-related stuff incoming, but I just happen to catch  this quote and thought it particularly important to save. 

Watch 🇨🇳李铁锤's broadcast: The last day of periscope!

https://www.pscp.tv/w/cy6EYjU0ODY4ODB8MXluSk9CQWtXbXZHUryBLCEuLwI5a9kn5CHUddJ3v1AjySBqRmJb_r-4D709


Watch @Jculturefan1's broadcast: Depressed

https://www.pscp.tv/w/cy6ICTU0ODY4ODB8MXluSk9CQWtvdm5HUu0sa8MIr59tvC5begZjIz8AvGmH0FaGJvXKCK1kORzI


Watch @JeffsJourney_Eh's broadcast: Broadcast #5 - Our last Saturday night here🙁let’s have dinner 🥩🥦and fun #love #chat #BeKind 🙏🤗

https://www.pscp.tv/w/cy6I-TU0ODY4ODB8MUJSS2pCckFvZ1ZLdw7rha8BTDG5bbB_pDEafZleSqYpQPbZQSv2_fGjgZH6


Watch @Dj_Zap's broadcast: The Last Saturday in the Scope 3-27-21 #Thedungeonparty #Thedungeonfam #fortheloveofmusic #musicheals #LetRideYall

https://www.pscp.tv/w/cy6JVzU0ODY4ODB8MVlxSkRlZEROb2F4VoHqZjGLopQ14USTonZeW9JZItNS5fLcukBf3TgcAEzw


Watch @_Anthropoid's broadcast: I’m a brain scientist, ask me anything one last time (on Periscope)

https://www.pscp.tv/w/cy6MUjU0ODY4ODB8MWpNSmdwcXJsTmd4TCYgDVwfWOaHZMadPGy5xqEPW2DnEZZHNhawqf_QK-kC


# "[Periscope] has made me a better person and a better scientist."

[Tweet](https://twitter.com/_anthropoid/status/1375899651052736514?s=21)

A bunch of Periscope-related stuff incoming, but I just happen to catch  this quote and thought it particularly important to save. 

Watch @kcjarvis's broadcast: Good BYE Periscope HELLO Happs  TEST BROADCAST. 🎥 Subscribe at Happs: https://happs.tv/@KenJarvis #live

https://www.pscp.tv/w/cy6MGTU0ODY4ODB8MXlOeGFXa0FNVmdHasgT8zhUWmnADZHAgSNz9vuBrtZxuWivLU58E5JJXSpa


Watch @mikuohashi_ch's broadcast: #Goodbye #Periscope #http://live.sk-knower.com/user/xmikuohashix

https://www.pscp.tv/w/cy6MATU0ODY4ODB8MXlvSk1Ba0RPWk5KUcqDu6uExvShCRFAvbHjn_akSgy94lGqIRxBDPWthzuN


Watch @kanji_k's broadcast: 6days to go until Periscope will go away. From my neighborhood 🌸

https://www.pscp.tv/w/cy6L5DU0ODY4ODB8MXlvS01Ba25vRVdLUXYesGUAYsikUVEAE2UogSPk4WzCOLaRls7EVE36edrn


https://www.pscp.tv/w/1yoKMAknoEWKQ

Watch @DOOMSDAY_2021's broadcast: Good bye👋🔥Periscope🔥📹🌎📹🤣

https://www.pscp.tv/w/cy6LljU0ODY4ODB8MWxQSnFYbllnRExHYoJ-MvmCDeTvHOJhyBsp5dnTXxNXG62c4iSitqjkLTyk


Watch @TimothyDavidTV's broadcast: Follow me on @HappsNews https://happs.tv/invite/@TimothyDavidTV

https://www.pscp.tv/w/cy6KzzU0ODY4ODB8MWt2SnBvV3FrUWtHRVs5SBdnbNi4wpZoH4dFyb55Jp6TQmElvkKHfhUZAOTB


Watch @kcjarvis's broadcast: MAJOR ANNOUNCEMENT: LAST PERISCOPE!!!!!!! New Group, New Platform #KJsAmazingSummer2021 #TodayInTravel

https://www.pscp.tv/w/cy6JdDU0ODY4ODB8MXluS09Cb3lxdkF4UsxbjkyYI9BvdKLeZbmqoJR-yXhxm0N5x-7hxOPuAseP


Watch t's broadcast: for the last mfn time

https://www.pscp.tv/w/cy6JZzU0ODY4ODB8MVJEeGxQZG9SbXJ4TI1tyBiLHNhzSnQ6XJDP24u8q4DJcyF_Tw0SOILcDlae


Watch 🇨🇳李铁锤's broadcast: The last day of periscope!

https://www.pscp.tv/w/cy6EYjU0ODY4ODB8MXluSk9CQWtXbXZHUryBLCEuLwI5a9kn5CHUddJ3v1AjySBqRmJb_r-4D709


Watch @Jculturefan1's broadcast: Depressed

https://www.pscp.tv/w/cy6ICTU0ODY4ODB8MXluSk9CQWtvdm5HUu0sa8MIr59tvC5begZjIz8AvGmH0FaGJvXKCK1kORzI


Watch @JeffsJourney_Eh's broadcast: Broadcast #5 - Our last Saturday night here🙁let’s have dinner 🥩🥦and fun #love #chat #BeKind 🙏🤗

https://www.pscp.tv/w/cy6I-TU0ODY4ODB8MUJSS2pCckFvZ1ZLdw7rha8BTDG5bbB_pDEafZleSqYpQPbZQSv2_fGjgZH6


Watch @Dj_Zap's broadcast: The Last Saturday in the Scope 3-27-21 #Thedungeonparty #Thedungeonfam #fortheloveofmusic #musicheals #LetRideYall

https://www.pscp.tv/w/cy6JVzU0ODY4ODB8MVlxSkRlZEROb2F4VoHqZjGLopQ14USTonZeW9JZItNS5fLcukBf3TgcAEzw


Watch @_Anthropoid's broadcast: I’m a brain scientist, ask me anything one last time (on Periscope)

https://www.pscp.tv/w/cy6MUjU0ODY4ODB8MWpNSmdwcXJsTmd4TCYgDVwfWOaHZMadPGy5xqEPW2DnEZZHNhawqf_QK-kC


# "[Periscope] has made me a better person and a better scientist."

[Tweet](https://twitter.com/_anthropoid/status/1375899651052736514?s=21)

A bunch of Periscope-related stuff incoming, but I just happen to catch  this quote and thought it particularly important to save. 

Watch @kcjarvis's broadcast: Good BYE Periscope HELLO Happs  TEST BROADCAST. 🎥 Subscribe at Happs: https://happs.tv/@KenJarvis #live

https://www.pscp.tv/w/cy6MGTU0ODY4ODB8MXlOeGFXa0FNVmdHasgT8zhUWmnADZHAgSNz9vuBrtZxuWivLU58E5JJXSpa


Watch @mikuohashi_ch's broadcast: #Goodbye #Periscope #http://live.sk-knower.com/user/xmikuohashix

https://www.pscp.tv/w/cy6MATU0ODY4ODB8MXlvSk1Ba0RPWk5KUcqDu6uExvShCRFAvbHjn_akSgy94lGqIRxBDPWthzuN


Watch @kanji_k's broadcast: 6days to go until Periscope will go away. From my neighborhood 🌸

https://www.pscp.tv/w/cy6L5DU0ODY4ODB8MXlvS01Ba25vRVdLUXYesGUAYsikUVEAE2UogSPk4WzCOLaRls7EVE36edrn


https://www.pscp.tv/w/1yoKMAknoEWKQ

Watch @DOOMSDAY_2021's broadcast: Good bye👋🔥Periscope🔥📹🌎📹🤣

https://www.pscp.tv/w/cy6LljU0ODY4ODB8MWxQSnFYbllnRExHYoJ-MvmCDeTvHOJhyBsp5dnTXxNXG62c4iSitqjkLTyk


Watch @TimothyDavidTV's broadcast: Follow me on @HappsNews https://happs.tv/invite/@TimothyDavidTV

https://www.pscp.tv/w/cy6KzzU0ODY4ODB8MWt2SnBvV3FrUWtHRVs5SBdnbNi4wpZoH4dFyb55Jp6TQmElvkKHfhUZAOTB


Watch @kcjarvis's broadcast: MAJOR ANNOUNCEMENT: LAST PERISCOPE!!!!!!! New Group, New Platform #KJsAmazingSummer2021 #TodayInTravel

https://www.pscp.tv/w/cy6JdDU0ODY4ODB8MXluS09Cb3lxdkF4UsxbjkyYI9BvdKLeZbmqoJR-yXhxm0N5x-7hxOPuAseP


Watch t's broadcast: for the last mfn time

https://www.pscp.tv/w/cy6JZzU0ODY4ODB8MVJEeGxQZG9SbXJ4TI1tyBiLHNhzSnQ6XJDP24u8q4DJcyF_Tw0SOILcDlae


https://www.pscp.tv/w/cy6EYjU0ODY4ODB8MXluSk9CQWtXbXZHUryBLCEuLwI5a9kn5CHUddJ3v1AjySBqRmJb_r-4D709

Watch @GhostInThe_City's broadcast: 5:58am

https://www.pscp.tv/w/czDM5zU0ODY4ODB8MVJEeGxQZG5nV3p4TAZYVXPJbHWV0UvGDbFu9LDa8BLAgMkEBMMQ-8e2h7j_

https://www.pscp.tv/jfmanory

Watch on #Periscope: 8 days until #Periscope Dies: how to download your scopes | (Ongoing Gist: http://bit.ly/scopeforever)

https://www.pscp.tv/w/cyoNrjU0ODY4ODB8MW1ueGVhWHlham94WMWQOw8P8j8wTBcLsZgtGKpBUmJgL-Q90WkmV7-IrYPn


LIVE on #Periscope: Periscope Funeral II (7 Days Left)

https://www.pscp.tv/w/cyogETU0ODY4ODB8MWVhS2JucGRkWG5LWIvIi9D73gxHS6R-eu2b3cJUz2e6FNH6sgFRM3XrMBPv


Watch 👩‍❤️‍💋‍👨Kristi Ann Jester💋's broadcast: Walking last scope for periscope last #7days

https://www.pscp.tv/w/cysleDU0ODY4ODB8MVJEeGxQbkF5Z0R4TFQF0X-a6QJpL5h2q9SW_DBiFYFhl4xHS-L1ZpSebWu0


Watch @MTendsToTravel's broadcast: Saying goodbye to the spiral staircase (oh, yeah, and Periscope) 😎

https://www.pscp.tv/w/cy5qBzU0ODY4ODB8MWxQS3FYbllhcE14YiZBbc8_j4n8gISGeEaioJ4ah9HuH94B2lK3pmEtzjmz


https://www.pscp.tv/westiewonder

https://www.pscp.tv/w/cy5qBzU0ODY4ODB8MWxQS3FYbllhcE14YiZBbc8_j4n8gISGeEaioJ4ah9HuH94B2lK3pmEtzjmz

‪#Periscope users looking for a way to keep in touch: I will add literally anybody to this List if we could use it as a temporary solution for a scoper directory- just tell me. ‬

https://twitter.com/i/lists/1374664072654958594

Watch 🇨🇳李铁锤's broadcast: The last day of periscope!

https://www.pscp.tv/w/cy6EYjU0ODY4ODB8MXluSk9CQWtXbXZHUryBLCEuLwI5a9kn5CHUddJ3v1AjySBqRmJb_r-4D709


Watch @Jculturefan1's broadcast: Depressed

https://www.pscp.tv/w/cy6ICTU0ODY4ODB8MXluSk9CQWtvdm5HUu0sa8MIr59tvC5begZjIz8AvGmH0FaGJvXKCK1kORzI


Watch @JeffsJourney_Eh's broadcast: Broadcast #5 - Our last Saturday night here🙁let’s have dinner 🥩🥦and fun #love #chat #BeKind 🙏🤗

https://www.pscp.tv/w/cy6I-TU0ODY4ODB8MUJSS2pCckFvZ1ZLdw7rha8BTDG5bbB_pDEafZleSqYpQPbZQSv2_fGjgZH6


Watch @Dj_Zap's broadcast: The Last Saturday in the Scope 3-27-21 #Thedungeonparty #Thedungeonfam #fortheloveofmusic #musicheals #LetRideYall

https://www.pscp.tv/w/cy6JVzU0ODY4ODB8MVlxSkRlZEROb2F4VoHqZjGLopQ14USTonZeW9JZItNS5fLcukBf3TgcAEzw


Watch t's broadcast: for the last mfn time

https://www.pscp.tv/w/cy6JZzU0ODY4ODB8MVJEeGxQZG9SbXJ4TI1tyBiLHNhzSnQ6XJDP24u8q4DJcyF_Tw0SOILcDlae


Watch @kcjarvis's broadcast: MAJOR ANNOUNCEMENT: LAST PERISCOPE!!!!!!! New Group, New Platform #KJsAmazingSummer2021 #TodayInTravel

https://www.pscp.tv/w/cy6JdDU0ODY4ODB8MXluS09Cb3lxdkF4UsxbjkyYI9BvdKLeZbmqoJR-yXhxm0N5x-7hxOPuAseP


Watch @TimothyDavidTV's broadcast: Follow me on @HappsNews https://happs.tv/invite/@TimothyDavidTV

https://www.pscp.tv/w/cy6KzzU0ODY4ODB8MWt2SnBvV3FrUWtHRVs5SBdnbNi4wpZoH4dFyb55Jp6TQmElvkKHfhUZAOTB


Watch @DOOMSDAY_2021's broadcast: Good bye👋🔥Periscope🔥📹🌎📹🤣

https://www.pscp.tv/w/cy6LljU0ODY4ODB8MWxQSnFYbllnRExHYoJ-MvmCDeTvHOJhyBsp5dnTXxNXG62c4iSitqjkLTyk


https://www.pscp.tv/w/1yoKMAknoEWKQ

Watch @kanji_k's broadcast: 6days to go until Periscope will go away. From my neighborhood 🌸

https://www.pscp.tv/w/cy6L5DU0ODY4ODB8MXlvS01Ba25vRVdLUXYesGUAYsikUVEAE2UogSPk4WzCOLaRls7EVE36edrn


Watch @mikuohashi_ch's broadcast: #Goodbye #Periscope #http://live.sk-knower.com/user/xmikuohashix

https://www.pscp.tv/w/cy6MATU0ODY4ODB8MXlvSk1Ba0RPWk5KUcqDu6uExvShCRFAvbHjn_akSgy94lGqIRxBDPWthzuN


Watch @kcjarvis's broadcast: Good BYE Periscope HELLO Happs  TEST BROADCAST. 🎥 Subscribe at Happs: https://happs.tv/@KenJarvis #live

https://www.pscp.tv/w/cy6MGTU0ODY4ODB8MXlOeGFXa0FNVmdHasgT8zhUWmnADZHAgSNz9vuBrtZxuWivLU58E5JJXSpa


# "[Periscope] has made me a better person and a better scientist."

[Tweet](https://twitter.com/_anthropoid/status/1375899651052736514?s=21)

A bunch of Periscope-related stuff incoming, but I just happen to catch  this quote and thought it particularly important to save. 

Watch 🇨🇳李铁锤's broadcast: The last day of periscope!

https://www.pscp.tv/w/cy6EYjU0ODY4ODB8MXluSk9CQWtXbXZHUryBLCEuLwI5a9kn5CHUddJ3v1AjySBqRmJb_r-4D709


Watch @Jculturefan1's broadcast: Depressed

https://www.pscp.tv/w/cy6ICTU0ODY4ODB8MXluSk9CQWtvdm5HUu0sa8MIr59tvC5begZjIz8AvGmH0FaGJvXKCK1kORzI


Watch @JeffsJourney_Eh's broadcast: Broadcast #5 - Our last Saturday night here🙁let’s have dinner 🥩🥦and fun #love #chat #BeKind 🙏🤗

https://www.pscp.tv/w/cy6I-TU0ODY4ODB8MUJSS2pCckFvZ1ZLdw7rha8BTDG5bbB_pDEafZleSqYpQPbZQSv2_fGjgZH6


Watch @Dj_Zap's broadcast: The Last Saturday in the Scope 3-27-21 #Thedungeonparty #Thedungeonfam #fortheloveofmusic #musicheals #LetRideYall

https://www.pscp.tv/w/cy6JVzU0ODY4ODB8MVlxSkRlZEROb2F4VoHqZjGLopQ14USTonZeW9JZItNS5fLcukBf3TgcAEzw


Watch @_Anthropoid's broadcast: I’m a brain scientist, ask me anything one last time (on Periscope)

https://www.pscp.tv/w/cy6MUjU0ODY4ODB8MWpNSmdwcXJsTmd4TCYgDVwfWOaHZMadPGy5xqEPW2DnEZZHNhawqf_QK-kC


# "[Periscope] has made me a better person and a better scientist."

[Tweet](https://twitter.com/_anthropoid/status/1375899651052736514?s=21)

A bunch of Periscope-related stuff incoming, but I just happen to catch  this quote and thought it particularly important to save. 

Watch @kcjarvis's broadcast: Good BYE Periscope HELLO Happs  TEST BROADCAST. 🎥 Subscribe at Happs: https://happs.tv/@KenJarvis #live

https://www.pscp.tv/w/cy6MGTU0ODY4ODB8MXlOeGFXa0FNVmdHasgT8zhUWmnADZHAgSNz9vuBrtZxuWivLU58E5JJXSpa


Watch @mikuohashi_ch's broadcast: #Goodbye #Periscope #http://live.sk-knower.com/user/xmikuohashix

https://www.pscp.tv/w/cy6MATU0ODY4ODB8MXlvSk1Ba0RPWk5KUcqDu6uExvShCRFAvbHjn_akSgy94lGqIRxBDPWthzuN


Watch @kanji_k's broadcast: 6days to go until Periscope will go away. From my neighborhood 🌸

https://www.pscp.tv/w/cy6L5DU0ODY4ODB8MXlvS01Ba25vRVdLUXYesGUAYsikUVEAE2UogSPk4WzCOLaRls7EVE36edrn


https://www.pscp.tv/w/1yoKMAknoEWKQ

Watch @DOOMSDAY_2021's broadcast: Good bye👋🔥Periscope🔥📹🌎📹🤣

https://www.pscp.tv/w/cy6LljU0ODY4ODB8MWxQSnFYbllnRExHYoJ-MvmCDeTvHOJhyBsp5dnTXxNXG62c4iSitqjkLTyk


Watch @TimothyDavidTV's broadcast: Follow me on @HappsNews https://happs.tv/invite/@TimothyDavidTV

https://www.pscp.tv/w/cy6KzzU0ODY4ODB8MWt2SnBvV3FrUWtHRVs5SBdnbNi4wpZoH4dFyb55Jp6TQmElvkKHfhUZAOTB


Watch @kcjarvis's broadcast: MAJOR ANNOUNCEMENT: LAST PERISCOPE!!!!!!! New Group, New Platform #KJsAmazingSummer2021 #TodayInTravel

https://www.pscp.tv/w/cy6JdDU0ODY4ODB8MXluS09Cb3lxdkF4UsxbjkyYI9BvdKLeZbmqoJR-yXhxm0N5x-7hxOPuAseP


Watch t's broadcast: for the last mfn time

https://www.pscp.tv/w/cy6JZzU0ODY4ODB8MVJEeGxQZG9SbXJ4TI1tyBiLHNhzSnQ6XJDP24u8q4DJcyF_Tw0SOILcDlae


Watch 🇨🇳李铁锤's broadcast: The last day of periscope!

https://www.pscp.tv/w/cy6EYjU0ODY4ODB8MXluSk9CQWtXbXZHUryBLCEuLwI5a9kn5CHUddJ3v1AjySBqRmJb_r-4D709


Watch @Jculturefan1's broadcast: Depressed

https://www.pscp.tv/w/cy6ICTU0ODY4ODB8MXluSk9CQWtvdm5HUu0sa8MIr59tvC5begZjIz8AvGmH0FaGJvXKCK1kORzI


Watch @JeffsJourney_Eh's broadcast: Broadcast #5 - Our last Saturday night here🙁let’s have dinner 🥩🥦and fun #love #chat #BeKind 🙏🤗

https://www.pscp.tv/w/cy6I-TU0ODY4ODB8MUJSS2pCckFvZ1ZLdw7rha8BTDG5bbB_pDEafZleSqYpQPbZQSv2_fGjgZH6


Watch @Dj_Zap's broadcast: The Last Saturday in the Scope 3-27-21 #Thedungeonparty #Thedungeonfam #fortheloveofmusic #musicheals #LetRideYall

https://www.pscp.tv/w/cy6JVzU0ODY4ODB8MVlxSkRlZEROb2F4VoHqZjGLopQ14USTonZeW9JZItNS5fLcukBf3TgcAEzw


Watch @_Anthropoid's broadcast: I’m a brain scientist, ask me anything one last time (on Periscope)

https://www.pscp.tv/w/cy6MUjU0ODY4ODB8MWpNSmdwcXJsTmd4TCYgDVwfWOaHZMadPGy5xqEPW2DnEZZHNhawqf_QK-kC


# "[Periscope] has made me a better person and a better scientist."

[Tweet](https://twitter.com/_anthropoid/status/1375899651052736514?s=21)

A bunch of Periscope-related stuff incoming, but I just happen to catch  this quote and thought it particularly important to save. 

Watch @kcjarvis's broadcast: Good BYE Periscope HELLO Happs  TEST BROADCAST. 🎥 Subscribe at Happs: https://happs.tv/@KenJarvis #live

https://www.pscp.tv/w/cy6MGTU0ODY4ODB8MXlOeGFXa0FNVmdHasgT8zhUWmnADZHAgSNz9vuBrtZxuWivLU58E5JJXSpa


Watch @mikuohashi_ch's broadcast: #Goodbye #Periscope #http://live.sk-knower.com/user/xmikuohashix

https://www.pscp.tv/w/cy6MATU0ODY4ODB8MXlvSk1Ba0RPWk5KUcqDu6uExvShCRFAvbHjn_akSgy94lGqIRxBDPWthzuN


Watch @kanji_k's broadcast: 6days to go until Periscope will go away. From my neighborhood 🌸

https://www.pscp.tv/w/cy6L5DU0ODY4ODB8MXlvS01Ba25vRVdLUXYesGUAYsikUVEAE2UogSPk4WzCOLaRls7EVE36edrn


https://www.pscp.tv/w/1yoKMAknoEWKQ

Watch @DOOMSDAY_2021's broadcast: Good bye👋🔥Periscope🔥📹🌎📹🤣

https://www.pscp.tv/w/cy6LljU0ODY4ODB8MWxQSnFYbllnRExHYoJ-MvmCDeTvHOJhyBsp5dnTXxNXG62c4iSitqjkLTyk


Watch @TimothyDavidTV's broadcast: Follow me on @HappsNews https://happs.tv/invite/@TimothyDavidTV

https://www.pscp.tv/w/cy6KzzU0ODY4ODB8MWt2SnBvV3FrUWtHRVs5SBdnbNi4wpZoH4dFyb55Jp6TQmElvkKHfhUZAOTB


Watch @kcjarvis's broadcast: MAJOR ANNOUNCEMENT: LAST PERISCOPE!!!!!!! New Group, New Platform #KJsAmazingSummer2021 #TodayInTravel

https://www.pscp.tv/w/cy6JdDU0ODY4ODB8MXluS09Cb3lxdkF4UsxbjkyYI9BvdKLeZbmqoJR-yXhxm0N5x-7hxOPuAseP


Watch t's broadcast: for the last mfn time

https://www.pscp.tv/w/cy6JZzU0ODY4ODB8MVJEeGxQZG9SbXJ4TI1tyBiLHNhzSnQ6XJDP24u8q4DJcyF_Tw0SOILcDlae


https://www.pscp.tv/w/cy6EYjU0ODY4ODB8MXluSk9CQWtXbXZHUryBLCEuLwI5a9kn5CHUddJ3v1AjySBqRmJb_r-4D709

Watch @GhostInThe_City's broadcast: 5:58am

https://www.pscp.tv/w/czDM5zU0ODY4ODB8MVJEeGxQZG5nV3p4TAZYVXPJbHWV0UvGDbFu9LDa8BLAgMkEBMMQ-8e2h7j_

