# "[iOS 15 - Features](https://www.apple.com/ios/ios-15-preview/features/)" 

iOS 15 brings amazing new features that help you connect, focus, explore, and do even more with iPhone.

## Key Features and Enhancements

### FaceTime

####  SharePlay: Watch together 

Bring movies and TV shows into your FaceTime calls and enjoy a rich, real-time connection with your friends while watching the same content.

####  SharePlay: Listen together 

Share music with your friends right in your FaceTime calls.

####  SharePlay: Share your screen 

Share your screen to bring web pages, apps, and more into your conversation on FaceTime.

####  SharePlay: Synced playback 

Pause, rewind, fast-forward, or jump to a different scene — everyone’s playback remains in perfect sync.

####  SharePlay: Shared music queue 

When listening together, anyone in the call can add songs to the shared queue.

####  SharePlay: Smart volume 

Dynamically responsive volume controls automatically adjust audio so you can hear your friends even during a loud scene or climactic chorus.

####  SharePlay: Multiple device support 

Connect over FaceTime on your iPhone while watching video on your Apple TV or listening to music on your HomePod.

####  SharePlay: Connect through audio, video, and text 

Access your group’s Messages thread right from the FaceTime controls and choose the mode of communication that matches the moment.

####  Portrait mode 

Inspired by the portraits you take in the Camera app, Portrait mode in FaceTime blurs your background and puts the focus on you.1

####  Grid view 

Lets you see people in your Group FaceTime calls in the same-size tiles, and highlights the current speaker so it’s easy to know who’s talking. You’ll see up to six faces in the grid at a time.

####  FaceTime links 

Invite your friends into a FaceTime call using a web link you can share anywhere.

####  Calendar integration 

Generate a web link for a FaceTime call while creating an event in Calendar, so everyone knows exactly where to meet and when.

####  Mute alerts 

Lets you know when you’re talking while muted. Tap the alert to quickly unmute and make sure your voice is heard.

####  Zoom 

An optical zoom control for your back camera helps you zero in on what matters when you’re on a FaceTime call.

### Messages

####  Shared with You 

Content sent to you over Messages automatically appears in a new Shared with You section in the corresponding app, so you can enjoy it when it’s convenient for you. Shared with You will be featured in Photos, Safari, Apple News, Apple Music, Apple Podcasts, and the Apple TV app.

####  Shared with You: Pins 

For content that’s especially interesting to you, you can quickly pin it in Messages, and it will be elevated in Shared with You, Messages search, and the Details view of the conversation.

####  Shared with You: Continue the conversation 

Alongside shared content in the corresponding apps, you can see who sent it and tap the sender to view the associated messages and continue the conversation — right from the app — without going to Messages.

####  Shared with You: Photos 

Photos sent to you over Messages automatically appear in your Photos app. Your library includes the photos you care about most — like the ones you were there for. And in For You, the broader set of shared photos will be featured in a new Shared with You section, your Memories, and your Featured Photos.

####  Shared with You: Safari 

Interesting articles, recipes, and other links sent over Messages automatically appear in the new Shared with You section on the Safari start page. Articles that can be found in Safari and Apple News conveniently appear in Shared with You in both apps — so you can enjoy them in either place.

####  Shared with You: Apple News 

Interesting stories sent over Messages automatically appear in the new Shared with You section in the Today and Following tabs in Apple News. Stories found in News and Safari appear in Shared with You in both apps — so you can enjoy them in either place.

####  Shared with You: Apple Music 

Music sent over Messages automatically appears in the new Shared with You section of Listen Now in Apple Music.

####  Shared with You: Apple Podcasts 

Podcast shows and episodes sent over Messages automatically appear in the new Shared with You section of Listen Now in Apple Podcasts.

####  Shared with You: Apple TV app 

Movies and shows sent over Messages automatically appear in the new Shared with You section of Watch Now in the Apple TV app.

####  Photo collections 

Enjoy multiple photos as beautiful collections in your Messages conversations. A handful of images appears as a glanceable collage and a larger set as an elegant stack that you can swipe through. Tap to view them as a grid and easily add a Tapback or inline reply.

####  Easily save photos 

You can quickly save photos sent to you by tapping a new save button right in the Messages conversation.

####  SMS filtering for Brazil 

Messages features on-device intelligence that filters unwanted SMS messages, organizing them into Promotional, Transactional, and Junk folders so your inbox can stay clutter‑free.

####  Notification options in Messages for India and China 

Turn notifications on or off for unknown senders, transactions, and promotions to determine which types of messages you want to receive notifications for.

####  Switch phone numbers in Messages 

Switch between phone numbers in the middle of a conversation on an iPhone with Dual SIM.

####  Clothing 

Customize your Memoji with over 40 outfit choices to reflect your style, mood, or the season — and choose up to three different colors. Show it off using Memoji stickers with expressive body language that include the upper body.

####  Two different eye colors 

Now you can select a different color for your left eye and your right eye.

####  New glasses 

Customize your Memoji with three new glasses options, including heart, star, and retro shapes. Select the color of your frame and lenses.

####  New Memoji stickers 

Nine new Memoji stickers let you send a shaka, a hand wave, a lightbulb moment, and more.

####  Multicolored headwear 

Represent your favorite sports team or university by choosing up to three colors for headwear.

####  New accessibility options 

Three new accessibility options let you represent yourself with cochlear implants, oxygen tubes, or a soft helmet.

####  Focus 

Match your devices to your mindset with Focus. Automatically filter notifications based on what you’re currently doing. Turn on Do Not Disturb to switch everything off, or choose from a provided Focus for work, personal time, sleep, fitness, mindfulness, gaming, reading, or driving.

####  Focus setup suggestions 

When you’re setting up a Focus, on‑device intelligence about your past activity suggests apps and people you want to allow notifications from.

####  Focus contextual suggestions 

Get intelligent suggestions about selecting a Focus based on your context, using different signals like location or time of day.

####  Focus customization 

Create a custom Focus to filter notifications based on what you’re currently doing. Choose an icon for your custom Focus and name it whatever you like.

####  Focus across your devices 

When you use a Focus on one device, it’s automatically set on your other devices.

####  Matching Home Screen pages with Focus 

Dedicate a page on your Home Screen to a specific Focus and organize your apps and widgets in a way that reduces temptation by making only related apps visible. The page appears when you’re in a Focus and hides everything else.

####  Allowed notifications 

Select the notifications you want from people and apps so that they get through to you while you’re focusing.

####  Status 

Contacts outside the notifications you allow for a Focus will be told that your notifications are silenced. Your status appears the moment someone tries to contact you in Messages, so they know not to interrupt.

####  Driving auto-reply 

Turn on an auto-reply for your contacts when they message you while you’re using the Focus for driving. You can customize your auto-reply to say whatever you like.

####  Urgent messages 

If someone’s status is turned on, signaling that they have notifications silenced with Focus, you can break through with an urgent message. If you’re on the receiving end, you can prevent an app or person from breaking through.

####  Status API 

For conversations in third-party messaging apps, developers can use your status to reflect that you’ve stepped away.

### Notifications

####  New look for notifications 

Notifications have a fresh new look, with contact photos for people and larger icons for apps.

####  Notification summary 

Receive a helpful collection of your notifications delivered daily, in the morning and evening, or scheduled at a time you choose. The summary is intelligently ordered by priority, with the most relevant notifications at the top, so you can quickly catch up.

####  Mute notifications 

Mute any app or messaging thread temporarily, for the next hour, or for the day.

####  Muting suggestions 

If a thread is really active and you aren’t engaging with it, you’ll get a suggestion to mute it.

####  Communication notifications 

Notifications from people across your communication apps now feature contact photos to make them easier to identify.

####  Time Sensitive notifications 

Time Sensitive notifications from apps are always delivered immediately, so you won’t miss out on timely alerts like a fraud alert, car waiting outside, or reminder to go pick up your kids.

####  Notification APIs 

New notification APIs for developers allow them to automatically send Time Sensitive notifications and adopt the new look for notifications coming from people.

####  New driving features 

A new dedicated driving map highlights details like traffic and incidents, and a route planner lets you view your upcoming journey by choosing a future departure or arrival time.

####  Immersive walking directions 

Get where you’re going with step-by-step directions shown in augmented reality.1

####  Redesigned transit 

The transit map has been redesigned for the new city experience and now shows key bus routes. While you’re riding transit, a new user interface makes it easy to see and interact with your route with one hand. And when you’re approaching your stop, Maps notifies you that it’s almost time to disembark.

####  Nearby transit 

Frequent transit riders can now get one-tap access to all departures that are near them. They can even pin their favorite lines so that they always show up at the top if they are nearby.

####  All-new place cards 

Completely redesigned place cards make it easy to find and interact with important information for businesses, explore details about cities, and learn about physical features like mountain ranges.

####  Editorially curated Guides Home 

It’s now easier to discover great places with the all-new Guides Home, an editorially curated destination where you can find Guides for places you’ll love.

####  Improved search 

When looking for places like restaurants, you can filter your search results by cuisine or whether they offer takeout. Or you can choose to see only places that are open right now. When you move the map while searching, Maps automatically updates your search results.

####  User account 

Maps users can now find their most used settings all in one place, including their preferred mode of transit, reported issues, favorites, and more.

####  Redesigned Maps contributions 

With an all-new design, it’s faster and easier to report an issue in Maps.

####  Bottom tab bar 

The bottom tab bar puts controls right at your fingertips. Swipe left or right on the address bar to move between tabs. Or swipe up to see all your open tabs.

####  Tab Groups 

Save and organize your tabs in the way that works best for you. Switch between Tab Groups in the tab overview.

####  Tab Group syncing 

Tab Groups sync across devices so you have access to your tabs from anywhere.

####  Customizable start page 

Customize the start page to make it your own. You can set a background image and select new sections to display, like Privacy Report, Siri Suggestions, and Shared with You. Customizations sync across devices, so you can have the same Safari everywhere.

####  New privacy protections 

Intelligent Tracking Prevention now also prevents trackers from profiling you using your IP address.

####  HTTPS upgrade 

HTTPS upgrade automatically uses HTTPS whenever available.

####  Pull to refresh 

Refresh a web page by pulling down from the top of the page.

####  Web extensions on iOS 

Personalize Safari on iOS with web extensions. Web extensions can add functionality and features to Safari. You can install extensions through the App Store.

####  Voice search 

Search the web using your voice. Tap the microphone in the search field and speak your search to see suggestions or be taken directly to the page you’re looking for.

####  Tab overview grid view 

The tab overview now displays your open tabs in a grid, making it easier to see the tabs you have open and switch between them. Tap the Tab Overview button or swipe up on the tab bar to see all your tabs.

####  ID in Wallet 

You can add your driver’s license and state ID to Wallet on your iPhone and a paired Apple Watch and present them securely at TSA checkpoints.5

####  Archived passes 

Your expired boarding passes and event tickets will be automatically moved to a separate list so you can easily access your relevant cards and passes without having to deal with the clutter of old passes.

####  Multiple-pass downloads 

Using Safari, you can now add multiple passes to Wallet in one action instead of manually adding one pass at a time.

### Live Text1

####  Live Text in photos 

Text is now completely interactive in all your photos, so you can use functions like copy and paste, lookup, and translate. Live Text works in Photos, Screenshot, Quick Look, and Safari and in live previews with Camera.

####  Visual Look Up 

Swipe up or tap the information button on any photo to highlight recognized objects and scenes. Learn more about popular art and landmarks around the world, plants and flowers out in nature, books, and breeds of pets.

### Spotlight

####  Rich results 

Brings together all the information you’re looking for in one rich result. Available for contacts, actors, musicians, movies, and TV shows.

####  Photos search 

Spotlight uses information from Photos to enable searching your full photo library by locations, people, scenes, or even things in the photos, like a dog or a car. Find images shared through Messages by including a contact name in your search.

####  Web images search 

Spotlight allows you to search for images of people, animals, monuments, and more from the web.

####  Lock Screen access 

Pull down from the Lock Screen or Notification Center to open Spotlight.

####  App Clips in Maps results 

For businesses that support App Clips, you’ll see an action button on the Maps result in Spotlight. Action buttons include Menu, Tickets, Reservations, Appointments, Takeout, Order, Delivery, Waitlist, Showtimes, Parking, Availability, and Pricing.

####  Improved App Store search 

Quickly install apps from the App Store without leaving Spotlight.

####  Memories: Apple Music 

In addition to the hundreds of newly included songs, Apple Music subscribers can add any of the tens of millions of songs from the Apple Music library to enjoy on their devices.

####  Memories: Song suggestions 

Apple Music song suggestions are personalized just for you, combining expert recommendations with your music tastes and what’s in your photos and videos. Song suggestions can even recommend songs that were popular at the time and location of the memory, songs you listened to while traveling, or a song from the artist you saw for a concert memory.

####  Memories: Memory mixes 

Customize your memory by swiping through Memory mixes, which let you audition different songs with pacing and a Memory look to match.

####  Memories: Fresh new look 

Memories has a fresh new look including animated cards with smart, adaptive titles, new animation and transition styles, and multiple image collages for a cinematic feel.

####  Memories: Memory looks 

Inspired by the art of cinematography, 12 Memory looks add mood by analyzing each photo and video and applying the right contrast and color adjustment to give them a consistent look — just as the colorists at film studios do.

####  Memories: Interactive interface 

Tap to pause, replay the last photo, skip to the next, or jump ahead, and the music keeps playing and the timing adjusts to keep the transitions on the beat. Change the song or Memory look or add or remove photos, and the adjustment happens in real time, without the need for the movie to recompile.

####  Memories: Browse view 

View all the content from your memory in a bird’s-eye view where you can add, remove, or change the memory duration or jump ahead to another part of the memory.

####  Memories: New memory types 

New memory types include additional international holidays, child-focused memories, trends over time, and improved pet memories, including recognizing individual dogs and cats.

####  Memories: Watch next 

Memories suggests related memories to watch next after your memory finishes playing.

####  Memories: On-device song suggestions 

Song suggestions are determined on device to protect your privacy.

####  Shared with You 

The Shared with You section in the For You tab allows you to view photos and videos that have been shared with you in Messages. Photos taken when you were present also appear in All Photos and in Days, Months, and Years views and can appear in your Featured Photos and Memories, including the Photos widget. Save a photo to your library or respond to the sender in Messages.

####  Richer Info pane 

Swipe up on a photo or tap the new info button to view information about the photo, such as the camera, lens, and shutter speed, the file size, or who sent a Shared with You photo in Messages. You can also edit the date taken or location, add a caption, and learn about items detected by Visual Look Up.

####  Faster iCloud Photos library initial sync 

When you upgrade to a new device, iCloud Photos syncs more quickly, so you can get to your photo library faster.

####  Limited Photos Library improvements in third-party apps 

Third-party apps can offer simpler selection workflows when you grant access to specific content in the Photos library.

####  People identification improvements 

The People album has improved recognition for individuals.

####  People naming workflow 

Correct naming mistakes more easily in the People album.

####  Selection order in the Photos image picker 

The Photos image picker, including in the Messages app, now allows you to select photos in a specific order for sharing.

####  Suggest less often 

Tap Feature Less to let Photos know you prefer to see less of a specific date, place, holiday, or person across Featured Photos, in the Photos widget, in Memories, or highlighted in the Library tab.

####  Share health data with others 

Share your health data with people important to you or those who are caring for you. Choose which data and trends to share, including heart health, activity, labs, vitals, Medical ID, cycle tracking, and more.

####  Share notifications with others 

People you share health data with can view health alerts you receive, including high heart rate and irregular rhythm notifications. You can also share notifications for significant changes that are identified in the shared data categories, such as a steep decline in activity.

####  Share health trends with Messages 

View trend analysis of someone’s health data that’s been shared with you and easily start a conversation with them about changes in their health by sharing a view of trend data through Messages.

####  Trends 

Trend analysis in the Health app lets you see at a glance how a given health metric is progressing, whether it’s increasing or decreasing over time. You can choose to receive a notification when a new trend has been detected in your health data.

####  COVID-19 immunizations and test results 

Scan a QR code from your healthcare provider and store your COVID-19 immunizations and test results securely in the Health app.

####  Mail Privacy Protection 

Mail Privacy Protection helps protect your privacy by preventing email senders from learning information about your Mail activity. If you choose to turn it on, it hides your IP address so senders can’t link it to your other online activity or determine your location. And it prevents senders from seeing if you’ve opened their email.

####  Secure paste 

Developers can allow you to paste content from another app without having access to what you’ve copied until you want them to have access.

####  Share current location 

Developers can let you share your current location with a customizable button in their apps. It’s an easy way for them to help you share your location just once, without further access after that session.

####  Limited Photos Library improvements in third‑party apps 

If you’ve granted limited access to your Photos library, third‑party apps can offer simpler selection workflows when you allow access to specific content in the library.

####  Fast on-device processing 

Processing on device means that Siri is incredibly fast.9

####  Sharing 

Share items onscreen like photos, web pages, content from Apple Music or Apple Podcasts, Apple News stories, Maps locations, and more. For example, just say “Send this to Vivek” and Siri will send it. If the item cannot be shared, Siri will offer to send a screenshot instead.

####  Refer to contacts onscreen 

Siri can now use onscreen context to send a message or place a call. For example, if you’re looking at a contact in the Contacts app, a conversation with someone in Messages, or a notification of a message or missed call from someone, you can say “Message them I’m on my way” and Siri will send it to the appropriate contact.

####  Maintaining context 

Siri is even better at maintaining context between requests, so you can conversationally refer to what you just asked. For example, after asking “Is Glacier National Park still open?” you could ask “How long does it take to get there?” and Siri will make the connection.

####  Announce Messages in CarPlay 

Siri can announce incoming messages in CarPlay. You can turn announcements on or off when a message is read and Siri will remember your preference. Or you can set announcements off or always on through Settings.

####  Control smart home accessories at a specific time 

You can ask Siri to control a HomeKit accessory at a specific time. For example, say “Hey Siri, turn off my bedroom lights at 7 p.m.” or “Hey Siri, turn off all the lights when I leave.”

####  Neural text-to-speech voice in more languages 

The latest neural text-to-speech voices are now available in more languages: Swedish (Sweden), Danish (Denmark), Norwegian (Norway), and Finnish (Finland).

####  Mixed English and Indic language support in Siri 

Ask Siri to play your favorite song, call a friend, and more using a mix of Indian English and your native language. Nine languages are supported: Hindi, Telugu, Kannada, Marathi, Tamil, Bengali, Gujarati, Malayalam, and Punjabi.

### Apple ID

####  Account Recovery Contacts 

Choose one or more people you trust to become an Account Recovery Contact to help you reset your password and regain access to your account.

####  Hide My Email 

Hide My Email allows you to create unique, random email addresses that forward to your personal inbox so you can send and receive email without having to share your real email address.

####  Custom email domain 

Personalize your iCloud Mail address with a custom domain name, and invite family members to use the same domain with their iCloud Mail accounts.

## Even More

### Accessibility

####  Explore images with VoiceOver 

Explore people, objects, text, and tables within images in more detail with VoiceOver. Navigate receipts and nutrition label values intelligently in logical order. And move your finger over a photo to discover a person’s position relative to other objects within images.

####  VoiceOver image descriptions in Markup 

Markup lets you add image descriptions that can be read by VoiceOver. Image descriptions persist even when shared and can be read in a range of supported apps on iPhone, iPad, and Mac.

####  Sound actions for Switch Control 

Sound actions for Switch Control let you control iPhone with simple mouth sounds — such as a click, pop, or “ee” sound — without the need for physical buttons, switches, or complex verbal commands.

####  Background sounds 

Background sounds play balanced, bright, or dark noise, ocean, rain, and stream sounds continuously in the background to mask unwanted environmental or external noise and help you focus, stay calm, or rest. The sounds mix into or duck under other audio and system sounds as you use your device.

####  Per-app settings 

Customize display and text size settings on an app-by-app basis. Bold or enlarge text, increase contrast, invert colors, add color filters, and more for only the apps you want.

####  Import audiograms 

Import paper or PDF audiograms in Settings and quickly customize Headphone Accommodations to amplify soft sounds and adjust certain frequencies based on your hearing test results.

####  Magnifier app 

Magnifier becomes a default app on iOS, so you can use your iPhone as a magnifying glass to zoom in on objects near you.

####  Accessibility Memoji 

Memoji represent more of your look and style with new customizations, including oxygen tubes, cochlear implants, and a soft helmet for headwear.

####  New Voice Control languages 

Voice Control adds new language options including Mandarin Chinese (China mainland), Cantonese (Hong Kong), Japanese (Japan), French (France), and German (Germany). These languages use Siri speech recognition technology for incredible accuracy as you dictate your commands.

### App Library

####  Reorder Home Screen pages 

Personalize your Home Screen by reordering pages.

### App Store

####  In-app events 

Discover timely events within apps and games — such as a game competition, a new movie premiere, or a livestreamed experience — right on the App Store. Events are discoverable in editorial curation and personalized recommendations on the Today, Games, and Apps tabs, in search results, and on the app product page.

####  App Store widget 

See the stories, collections, and in-app events from your Today tab right on your Home Screen.

### Apple Card

####  Advanced Fraud Protection 

With Advanced Fraud Protection, Apple Card users can have a security code that changes regularly to make online Card Number transactions even more secure.

####  Improved card number discoverability 

Now quickly view your card number by opening Apple Card in Wallet and tapping the card icon.

### Apple Pay

####  Apple Pay new payment sheet design 

A redesigned Apple Pay payment sheet lets you add new cards inline, without ever leaving the Apple Pay experience. You can now enter coupon codes into the payment sheet, helping you save more whenever you use Apple Pay. And the enhanced summary view lets you see more detailed information, such as payment items, discounts, and subtotals, giving you the confidence to shop with Apple Pay.

### Augmented Reality

####  Search redesign 

Search results come up as soon as you start typing and will correct spelling mistakes. Enjoy personalized showcases of top books, audiobooks, and genre collections within your results. Buy directly from the Search tab to get started on your book faster.

####  Improved Panorama captures 

Panorama mode in iPhone 12 models and later has improved geometric distortion and better captures moving subjects while also reducing image noise and banding.

####  Zoom in QuickTake video 

Swipe up or down while taking a QuickTake video to zoom in or out.15

####  Select from UPI payment apps in India 

Choose from up to 10 of your most recently used UPI payment apps when you scan UPI QR codes using the Camera app for merchant payments.

### Car Keys

####  Announce Messages in CarPlay 

Siri can announce incoming messages in CarPlay. You can turn announcements on or off when a message is read and Siri will remember your preference. Or you can set announcements off or always on through Settings.

### Dictionary

####  New dictionaries for India 

Bilingual dictionaries for India include Urdu–English, Tamil–English, Telugu–English, and Gujarati–English.

####  New thesaurus and idiom dictionary for China mainland 

There’s a new Simplified Chinese thesaurus with synonyms and antonyms as well as a dictionary of idioms.

####  New dictionaries for Hong Kong 

Dictionaries now include a Traditional Chinese–English dictionary of Cantonese colloquialisms and a Traditional Chinese dictionary of Standard Mandarin with Cantonese pronunciations.

####  Live locations for family and friends 

See your family and friends’ locations with continuous streaming updates. This provides an immediate sense of direction, speed, and progress when viewing people’s locations.

####  Locate when powered off 

Locate your devices using the Find My network for up to 24 hours even after they have been turned off. This can help you locate a missing device that may have been turned off by a thief.

####  Locate after erase 

The Find My network and Activation Lock can locate your device even after it has been erased. To help ensure that nobody is tricked into purchasing your device, the Hello screen will clearly show that your device is locked, locatable, and still yours.

####  Separation alerts 

Enable separation alerts, and if you leave a device, AirTag, or compatible third-party item behind, your iPhone will alert you with notifications and Find My will give you directions to your item.

####  Find My network support for AirPods 

Use the Find My network to get an approximate location of your missing AirPods Pro or AirPods Max. This will help you get within Bluetooth range so you can play a sound and locate them.

####  Find My widget 

Keep track of your friends and personal items right from the Home Screen with the Find My widget.

####  5G preferred over Wi-Fi 

Your iPhone 12 models and later now automatically prioritize 5G when Wi‑Fi connectivity on networks you visit occasionally is slow, or when you are connected to captive or insecure networks, so you can enjoy faster, safer connectivity.

####  Game Center recents and groups invitations 

Bring your most recent Messages friends and groups into Game Center–enabled games with the new multiplayer friend selector.

####  Game Center friend requests 

See incoming requests in the Game Center friend request inbox. Navigate to the App Store or within your Game Center profile in a game.

####  Game highlights 

With a press of the share button, save a video clip of up to the last 15 seconds of gameplay using game controllers like the Xbox Series X|S Wireless Controller or Sony PS5 DualSense™ Wireless Controller.

####  Game Center widgets 

The Continue Playing widget displays your recently played Game Center–enabled games across devices. The Friends Are Playing widget helps you discover the games your friends play.

####  Focus for gaming 

Choosing the Focus for gaming lets you stay fully immersed in your game by filtering out unwanted notifications.

####  Package detection 

Using HomeKit Secure Video, your security cameras and video doorbells can now detect and notify you when a package has arrived.13

### Inclusive Language

####  Choose your term of address 

Choose your term of address for Spanish to make your device feel more personal. In Language & Region settings you can choose how you would like to be addressed throughout the system: feminine, masculine, or neuter.

### Keyboard

####  Magnification loupe for text cursor and selection 

Select exactly the text you want with an improved cursor that magnifies the text you’re looking at.

####  Vietnamese VNI and VIQR keyboards 

Type in Vietnamese using VNI and VIQR, two of the most popular input methods.

####  QuickPath language expansion 

New languages that support QuickPath include Dutch, Swedish, and Vietnamese.

####  New keyboard layouts 

New keyboard layouts for Ainu, Amharic, Assyrian, Fula (Adlam), Igbo, Navajo, and Rohingya offer more language options.

####  Enhanced 10-key layout for Chinese Pinyin 

Enhanced 10-key layout includes improvements that let you quickly switch to QWERTY, access symbols more easily, and type words that share the same keys with greater accuracy by allowing you to select the exact Pinyin for more than just the first syllable in the phrase.

####  Suggestions for Cantonese and Shanghainese 

Type words and phrases in Cantonese and Shanghainese more easily when using the Simplified Chinese keyboard.

####  Smart Replies for Hindi 

Smart Replies now support Hindi and Hindi (Latin).

### Keyboard Dictation

####  Continuous dictation 

With on-device dictation, you can dictate text of any length without a timeout (previously limited to 60 seconds).19

####  Shared with You 

See all the music your friends have shared with you in one place, right in the Music app. And when browsing music, quickly jump back to Messages to keep the conversation going.

####  Photo Memories 

Bring memories to life with Apple Music. Select tracks from your library or from the catalog to create the perfect soundtrack to accompany your memory and share it with your friends.

####  SharePlay 

Use SharePlay in FaceTime to listen to music together in real time. You can pick out songs with your friends, and everyone can pause, rearrange, or skip tracks in the SharePlay queue.

####  Redesigned News feed 

A new design makes it easier to browse and interact with your News feed. Information like publication dates and bylines are more prominent, and you can save and share stories right from the feed.

####  Shared with You 

Interesting stories sent over Messages automatically appear in the Shared with You section in the Today and Following tabs in Apple News. Stories found in News and Safari appear in Shared with You in both apps.

####  Tags 

Tags are a fast and flexible way to categorize and organize your notes. Add one or more tags by typing them directly in the note — like #activities or #cooking.

####  Tag Browser 

The Tag Browser lets you tap any tag or combination of tags to quickly view tagged notes.

####  Custom Smart Folders 

Custom Smart Folders automatically collect notes in one place based on tags.

####  Activity view 

See what others have added to your shared note while you were away. The new Activity view gives a summary of updates since the last time you viewed the note and a day-to-day list of activity from each collaborator.

####  Highlights 

Swipe right anywhere in your note to reveal details of who made changes in a shared note. View edit times and dates with highlighted text color-coded to match collaborators in the note.

####  Mentions 

Mentions make collaboration in shared notes or folders more social, direct, and contextual. Type or handwrite an @ sign and the name of a collaborator anywhere in your note to notify them of important updates and link them back to the note.

####  Quick Note: Easy to access 

Find and edit the Quick Notes you created on Mac and iPad in Notes.

####  Drag and drop 

With support for drag and drop across apps, you can pick up images, documents, and files from one app and drag them into another.

### Passwords

####  Built-in authenticator 

Generate verification codes needed for additional sign-in security. If a site offers two-factor authentication, you can set up verification codes under Passwords in Settings — no need to download an additional app. Once set up, verification codes autofill when you sign in to the site.

### Podcasts

####  Personalized recommendations 

Discover new podcasts about topics you’re passionate about. The best podcasts, personalized for you, grouped by topics you care about.

####  Shared with You 

Share your favorite podcast episodes in the Messages app and find all the episodes shared with you in Listen Now.

### Reminders

####  Tags 

Tags are a fast and flexible way to organize your reminders. Add one or more tags, like #errands, to your reminders to make them easy to search and filter for across your Reminders lists.

####  Tag Browser 

The Tag Browser lets you tap any tag or combination of tags to quickly view tagged reminders.

####  Custom Smart Lists 

Create your own Smart Lists to automatically include reminders that matter most to you by selecting for tags, dates, times, locations, flags, and priority. Choose more than one tag (such as #gardening and #errands) and combine them with other setting filters for more specific lists.

####  Delete completed reminders 

Access quick options to easily delete your completed reminders.

####  Improved natural language support 

Type more advanced phrases to create reminder settings. Try something like “Jog every other morning” for a specific, recurring reminder.

####  Expanded suggested attributes 

Choose tags, flags, priority, and people you message with a quick tap when creating a reminder.

####  Announce Reminders with Siri on AirPods 

Siri can announce your reminders when you’re wearing AirPods or compatible Beats headphones.

### Screen Time

####  Screen Time API 

Developers can use the Screen Time API in parental controls apps to support an even wider range of tools for parents. The API provides developers with key features like core restrictions and device activity monitoring, all in a way that puts privacy first.

####  Downtime on demand 

Turn on downtime on demand. During downtime, only phone calls and apps you choose to allow will be available. A five‑minute downtime reminder will be sent and downtime will be turned on until the end of the day.

### Settings

####  Software Updates 

iOS may now offer a choice between two software update versions in the Settings app. You can update to the latest version of iOS 15 as soon as it’s released for the latest features and most complete set of security updates. Or continue on iOS 14 and still get important security updates.

### Setup Experience

####  Temporary iCloud storage to transfer your data 

Now when you buy a new device you can use iCloud Backup to move your data to your new device, even if you’re low on storage. iCloud will grant you as much storage as you need to complete a temporary backup, free of charge, for up to three weeks. This allows you to get all your apps, data, and settings onto your device automatically.

####  More content transferred from Android 

Move to iOS can now also move your photo albums, files and folders, and Accessibility settings so your new iPhone feels even more like your own.

####  App discoverability 

It’s easier than ever to get the Move to iOS app. Simply scan the QR code, and you’ll be taken to the Google Play Store where you can download the app.

### Shortcuts

####  Cross-device management 

Build and manage shortcuts on iPhone, iPad, or Mac for any of your devices — shortcuts automatically sync across all of them.

####  Improved sharing 

Share shortcuts as easily as sharing a link and download them for your own use without managing complicated security settings. If you’re the recipient, smart prompts allow you to share only the data you want.

####  Smarter Shortcuts editor 

Next Action Suggestions help you complete the shortcut you’re building.

### System Font

####  SF Arabic system font 

The new SF Arabic system font features a refined, contemporary design that is integrated with the SF font, providing a clear, cohesive reading experience.

### Translate

####  System‑wide translation 

Translate text by selecting it and tapping Translate. Then copy, save, replace selected text, or open the translation in the Translate app. You can also translate selected text in photos.

####  Auto Translate 

Translate speech without tapping the microphone button in a conversation. Auto Translate automatically detects when you start speaking and when you stop, so the other person can just respond.

####  Face to face view 

Change the conversation view when chatting face to face so that each person can see the conversation from their own side.

####  Redesigned conversations 

Start a conversation using the Conversation tab in landscape or portrait view. The redesigned conversation view has chat bubbles so you can follow along more easily.

####  Easier language selection 

Selecting languages is now easier with convenient drop‑down menus.

####  Shared with You 

The Apple TV app now helps you see all the shows and movies your friends and family have shared with you in Messages. See them in a new dedicated section called Shared with You on Watch Now and easily keep the conversation going directly from the Apple TV app.

####  SharePlay 

The Apple TV app works seamlessly with Messages and FaceTime so you can watch your favorite shows and movies together with friends and communicate using text, voice, or video while you watch. SharePlay lets your friends join in from their iPhone, iPad, Mac, or Apple TV — so everyone can watch together wherever and however they want.

####  Now works with streaming apps in Japan 

The Apple TV app now works with popular streaming apps in Japan. Connect your favorite apps and use Up Next to continue where you left off from all your favorite shows and movies all in one place. Browse each service through the Apple TV app to easily discover and watch the best of what’s on TV.

### Voice Memos

####  Playback speed 

Speed up or slow down playback of Voice Memos recordings.

####  Skip silence 

Voice Memos analyzes your recordings and automatically skips over gaps in your audio with a single tap.

####  Improved sharing 

Share multiple Voice Memos recordings at once.

####  Next-hour precipitation notifications 

Get a notification when rain, snow, hail, or sleet is about to start or stop.23

####  New design 

The layout adjusts to show the most important weather information for that location and includes new maps modules, an updated 10‑day forecast, and new graphical weather data.

####  New animated backgrounds 

There are now thousands of variations of animated backgrounds that more accurately represent the sun position, clouds, and precipitation.1

####  Find My widget 

Keep track of your friends and personal items right from the Home Screen with the Find My widget.

####  Contacts widget 

Stay connected to family and friends from your Home Screen with the Contacts widget. Reach them via Phone, Messages, FaceTime, Mail, or Find My. With Family Sharing, you can take additional actions, like approving purchases or Screen Time requests from your kids.

####  Game Center widgets 

The Continue Playing widget displays your recently played Game Center–enabled games across devices. The Friends Are Playing widget helps you discover the games your friends play.

####  App Store widget 

See the stories, collections, and in‑app events from your Today tab right on your Home Screen.

####  Sleep widget 

See data about how you slept and review your sleep schedule with the Sleep widget.

####  Mail widget 

Glance at your latest email and get quick access to one of your mailboxes with the Mail widget.

####  Default widgets 

When you upgrade, you’ll see a new default layout, with widgets from the apps you use most arranged in Smart Stacks.

####  Intelligent widget suggestions 

Suggested widgets for apps you already use can automatically appear in your Smart Stack at the right time based on your past activity. An option lets you add the widget to your stack so it’s always there when you need it.

####  Reorder Smart Stacks 

Easily reorder the widgets in your Smart Stacks right from the Home Screen with new controls.

-"[iOS 15 - Features](https://www.apple.com/ios/ios-15-preview/features/)"