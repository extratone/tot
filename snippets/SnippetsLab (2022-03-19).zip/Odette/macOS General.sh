shutdown /s

shortcuts sign -m anyone -i “a.shortcut" -o "Test-Signed.shortcut"

$ osascript -e 'tell application "Tot" to open location "tot://7/content"'

Enable: defaults write com.apple.MobileSMS MMSShowSubject 1
Disable: defaults write com.apple.MobileSMS MMSShowSubject 0

cd ~/Library/Application\ Support
killall bird && rm -rf CloudDocs

defaults write -g NSUserKeyEquivalents -dict-add "Special Characters..." nul

sudo pmset sleepnow

imessage --text "<clipboard>" --contacts "asphaltapostle@icloud.com"

imessage --text "GoodMorning" --contacts "asphaltapostle@icloud.com" --attachment '2021.png'

shortcuts://x-callback-url/run-shortcut?name=Dark%20Odette

softwareupdate -l
sudo softwareupdate -ia --verbose

df -h
open .

shortcuts sign —-mode people-who-know-me —-input * —-output *
shortcuts sign —-mode people-who-know-me --input *.shortcut --output signed/*.shortcut


writeas post -c blog 
writeas post -c chaff --font sans
writeas publish -c chaff --font sans