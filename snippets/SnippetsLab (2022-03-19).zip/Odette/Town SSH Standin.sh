ssh extratone@tilde.town
sudo ssh-add .ssh/tilde.town
ssh-agent /bin/zsh

cat /etc/shells